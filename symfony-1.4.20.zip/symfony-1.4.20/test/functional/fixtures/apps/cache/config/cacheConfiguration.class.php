<?php

class cacheConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
