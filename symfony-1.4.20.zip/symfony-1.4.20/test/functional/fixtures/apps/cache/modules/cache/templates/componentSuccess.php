<div id="cacheableComponent"><?php include_component('cache', 'cacheableComponent') ?></div>
<div id="cacheableComponent"><?php include_component('cache', 'cacheableComponent') ?></div>
