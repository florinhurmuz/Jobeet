<?php

class myLibClass
{
  static public function ping()
  {
    return 'pong';
  }
}
