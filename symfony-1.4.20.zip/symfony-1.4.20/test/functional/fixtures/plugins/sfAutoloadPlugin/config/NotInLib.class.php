<?php

class NotInLib
{
}
